import sys
import os
import math
import random
import time

def main():
    szam=str(2**256)
    print("{0}".format(len(szam)))


if __name__ == '__main__':
    main()
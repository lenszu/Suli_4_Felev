import sys
import os
import math
import random
import time


def main():
    a = input("írj ide egy neve: ")
    a=a.strip()
    print("Hello {0}".format(a))


if __name__ == '__main__':
    main()

import sys
import os
import math
import random
import time

def Rev(szam):
    s=str(szam)
    return s[::-1]
    

def main():
    print("{0}".format(Rev("12345")))


if __name__ == '__main__':
    main()
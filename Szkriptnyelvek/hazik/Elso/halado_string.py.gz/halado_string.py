import sys
import os
import math
import random
import time


def main():
    a="sziasztok"
    print("Egy halado format metodus bemutatasa\n")
    print(f"Kezdetben: {a}")
    print(f"menetkozben formazas utan: {a.upper()}")


if __name__ == '__main__':
    main()
import sys


def utso(s):
    return s[3]

def utso_2(s):
    return int(s.split(":")[0])

def utso_3(s):
    return s[1]


def main():
    
    data = [
        (1, 'Albany', 'NY', 162692),
        (3, 'Allegany', 'NY', 11986),
        (121, 'Wyoming', 'NY', 8722),
        (123, 'Yates', 'NY', 5094)
    ]
    
    print(sorted(data,key=utso,reverse=True))
    
    users = ['10:User1', '80:User2', '100:User3', '00:User4', '75:User4', '45:User5']
    
    print(sorted(users,key=utso_2,reverse=True))
    
    li=[ [2, 6], [1, 3], [5, 4] ]
    
    print(sorted(li,key=utso_3,reverse=True))


if __name__ == "__main__":
    main()

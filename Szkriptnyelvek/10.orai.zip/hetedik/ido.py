import sys
import datetime
def main():
    print("Hello world")
    most=datetime.date.today()
    most_2=datetime.datetime.now()
    print(str(most).split("-"))
    print(most_2.strftime("%d/%m/%Y %H:%M:%S"))

    ido_objektum=datetime.datetime.strptime("2023-04-24","%Y-%m-%d")
    print(ido_objektum)
if __name__=="__main__":
    main()
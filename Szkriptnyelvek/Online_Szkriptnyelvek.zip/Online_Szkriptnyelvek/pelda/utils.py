def is_palindrome(s):
    if s == s[::-1]:
        return True
    else:
        return False


def duplaz(n):
    return 2 * n

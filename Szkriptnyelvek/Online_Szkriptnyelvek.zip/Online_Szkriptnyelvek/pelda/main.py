#!/usr/bin/env python3

from utils import duplaz, is_palindrome

def main():
    print(duplaz(8))
    print(is_palindrome("anna"))

##############################################################################

if __name__ == "__main__":
    main()
